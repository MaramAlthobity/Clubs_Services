-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: q68u8b2buodpme2n.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306
-- Generation Time: Mar 18, 2019 at 06:52 AM
-- Server version: 5.7.23-log
-- PHP Version: 7.2.15-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ob2xblnb3mi5u1tk`
--

-- --------------------------------------------------------

--
-- Table structure for table `Clubs`
--

CREATE TABLE `Clubs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `menFees` int(11) DEFAULT NULL,
  `womenFees` int(11) DEFAULT NULL,
  `childFees` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Clubs`
--

INSERT INTO `Clubs` (`id`, `name`, `image`, `password`, `phoneNumber`, `email`, `location`, `time`, `menFees`, `womenFees`, `childFees`, `gender`, `createdAt`, `updatedAt`) VALUES
(1, 'Fitness Time Club', 'https://www.firmdalehotels.com/media/1036949/crosby-street-hotel-gym.jpg?a=1&anchor=center&mode=crop&width=798&height=544&bgcolor=fff', 'password', '1798712698723', 'fitnessclub@gmail.com', 'Taif', 'Open 12:00 Closes 16:00', 300, 200, 100, 'Female', '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(2, 'Health Clubs', 'https://media.wmagazine.com/photos/5853339ac7188f9b26c915ea/3:2/w_640/Dogpound_Group-Workout-2.jpg', 'password', '123698123', 'healthclub@gmail.com', 'Jeddah', 'Open 08:00 Closes 16:00', 500, 400, 100, 'Male', '2019-03-01 21:25:17', '2019-03-01 22:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `Equipment`
--

CREATE TABLE `Equipment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `clubId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Equipment`
--

INSERT INTO `Equipment` (`id`, `name`, `image`, `clubId`, `createdAt`, `updatedAt`) VALUES
(1, 'Biking exercise machine', 'https://images.sportsdirect.com/images/products/76067369_4pl.jpg', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(2, 'Fitness Power Treadmill', 'https://images.sportsdirect.com/images/products/76067069_4pl.jpg', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(3, 'Hex Weights', 'https://images.sportsdirect.com/images/products/76004581_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(4, 'Weight Vest', 'https://images.sportsdirect.com/images/products/76140646_4pl.jpg', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(5, 'Kettle Bell', 'https://images.sportsdirect.com/images/products/76137292_4pl.jpg', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(6, 'Biking exercise machine', 'https://images.sportsdirect.com/images/products/76043402_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(7, 'Cross Trainer', 'https://images.sportsdirect.com/images/products/77600669_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(8, 'Upright Bike', 'https://images.sportsdirect.com/images/products/76066369_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(9, 'Fitness Super Duke Bike', 'https://images.sportsdirect.com/images/products/76086403_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(10, 'Walkrunner RPX Treadmill', 'https://images.sportsdirect.com/images/products/76031503_4pl.jpg', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `Reservations`
--

CREATE TABLE `Reservations` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `clubId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Reservations`
--

INSERT INTO `Reservations` (`id`, `userId`, `clubId`, `createdAt`, `updatedAt`, `startDate`, `endDate`) VALUES
(1, 1, 1, '2019-03-14 05:12:40', '2019-03-14 05:12:40', '2019-03-14 08:12:00', '2019-03-16 08:12:00'),
(7, 1, 1, '2019-03-15 19:14:41', '2019-03-15 19:14:41', '2019-03-19 22:14:00', '2019-03-31 22:14:00'),
(10, 5, 2, '2019-03-18 04:40:47', '2019-03-18 04:40:47', '2019-03-18 07:40:00', '2019-03-27 07:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `Schedules`
--

CREATE TABLE `Schedules` (
  `id` int(11) NOT NULL,
  `day` varchar(255) NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `trainerId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Schedules`
--

INSERT INTO `Schedules` (`id`, `day`, `startTime`, `endTime`, `trainerId`, `createdAt`, `updatedAt`) VALUES
(1, 'Monday', '12:00:00', '15:00:00', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `SequelizeMeta`
--

CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SequelizeMeta`
--

INSERT INTO `SequelizeMeta` (`name`) VALUES
('20190227185044-create-user.js'),
('20190227200234-create-club.js'),
('20190302043752-create-reservation.js'),
('20190302043809-create-trainer.js'),
('20190302043816-create-schedule.js'),
('20190302043828-create-service.js'),
('20190302043840-create-equipment.js'),
('20190302043845-create-workout.js'),
('20190303034203-create-add-reservation-time.js');

-- --------------------------------------------------------

--
-- Table structure for table `Services`
--

CREATE TABLE `Services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `clubId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Services`
--

INSERT INTO `Services` (`id`, `name`, `image`, `description`, `clubId`, `createdAt`, `updatedAt`) VALUES
(1, 'Swimming Pool', 'https://www.visitreykjanes.is/static/toy/images/img_1247-copy.jpg', 'A very modern swimming pool with the latest swimming equipment', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(2, 'Football Stadium', 'https://cdn7.dissolve.com/p/D328_12_011/D328_12_011_0004_600.jpg', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(3, 'Basketball Stadium', 'https://usatftw.files.wordpress.com/2015/11/screen-shot-2015-11-10-at-12-08-48-pm.png?w=1000&h=600&crop=1', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(4, 'Yoga Studio', 'https://fundbox.com/blog/wp-content/uploads/2016/09/shutterstock_179250509-940x467.jpg', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(5, 'Badminton', 'http://campboulevard.com/wp-content/uploads/Badminton_.png', 'Awesome rackets, a stadium ready for you to join in', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(6, 'Table Tennis', 'http://mcfcomplex.in/wp-content/uploads/2017/04/tt-mcf.jpg', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(7, 'Swimming Pool', 'https://i0.wp.com/www.nat.is/wp-content/uploads/2017/10/picture_2.png?fit=600%2C450&ssl=1', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(8, 'Dancing Studio', '', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(9, 'Indoor games', 'https://i.ytimg.com/vi/MgljU8wtp_Q/maxresdefault.jpg', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `Trainers`
--

CREATE TABLE `Trainers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `clubId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Trainers`
--

INSERT INTO `Trainers` (`id`, `name`, `image`, `age`, `activity`, `clubId`, `createdAt`, `updatedAt`) VALUES
(1, 'Rupert Enlow', 'https://www.academyoffitnessprofessionals.com/wp-content/uploads/2016/08/gym-instructor-courses.jpg', '27', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(2, 'Rupert Enlow', 'https://focus-training.com/app/uploads/Gym-instructor-FT-600.jpg', '25', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(3, 'Danial Milo', 'http://watchfit.com/wp-content/uploads/2015/07/gym-instructor_1-1024x750.jpeg', '21', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(4, 'Toby Leak', 'https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX4744237.jpg', '22', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(5, 'Temika Burkhalter', 'https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX4148134.jpg', '40', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(6, 'Celesta Esses', 'https://www.colourbox.com/preview/5238191-female-gym-instructor-writing-diet-chart.jpg', '35', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(7, 'Rubin Gordy', 'https://image.shutterstock.com/image-photo/portrait-muscular-trainer-writing-on-260nw-296585468.jpg', '36', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(8, 'Lacy Boldt ', 'https://www.bodyaidsolutions.co.uk/wp-content/uploads/2015/05/iStock_000025722951_Large-380x254.jpg', '24', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(9, 'Charity Kellerman', 'https://d1jp63uxrnx10jb5u2tz125u-wpengine.netdna-ssl.com/wp-content/uploads/2017/08/fitness-pro-planks-dp-300x250-300x250.jpg', '28', '', 2, '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(10, 'Alisha Penta', 'https://byebyebellyblog.com/wp-content/uploads/2017/06/fitness-instructor.jpg?w=640', '20', '', 1, '2019-03-01 21:25:17', '2019-03-01 22:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `name`, `password`, `email`, `phoneNumber`, `gender`, `createdAt`, `updatedAt`) VALUES
(1, 'Someone', '$2b$10$JsEIZ6hsWRGa6zwcDX6Ny.wz0h/66LuaYW0bBqlCWH.XpJkOwztbW', 'someone@gmail.com', '07123456789', 'Male', '2019-03-12 18:01:41', '2019-03-12 18:02:19'),
(2, 'm', '$2b$10$MB0Y1G9rMO8qrfivHHemWuvWJND0nNalgpRZEnWW.QFgLVxekmkbe', 'm@hotmail.com', '057766', 'Female', '2019-03-12 21:28:04', '2019-03-13 12:33:34'),
(3, 'Test2@test.com ', '$2b$10$YS08DeyDcN/A0W/URjQ6oOpFE.hsBWNNiL0UJzrqLkI4dxPWHXs1q', 'test2@test.com', '05096964558', NULL, '2019-03-12 22:27:49', '2019-03-12 22:27:49'),
(4, 'maram', '$2b$10$LAQJZ0ddPv7HYVAxHgJx7OFC0uf3Hh8GuWchl7rXroRgSa.2y8K6m', 'm@gmail.com', '050571', 'Male', '2019-03-16 11:10:37', '2019-03-16 11:31:33'),
(5, 'Random Name', '$2b$10$4txXLD9sQKRHMM.019uuV.D33/M.99Pl0KOo6Qtym42zMnNK1gY1W', 'ranomEmail@emails.com', '+15555215554', 'Male', '2019-03-18 04:35:16', '2019-03-18 04:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `Workouts`
--

CREATE TABLE `Workouts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Workouts`
--

INSERT INTO `Workouts` (`id`, `name`, `image`, `video`, `createdAt`, `updatedAt`) VALUES
(1, 'Super-Pump Arm Workout', '', 'https://www.youtube.com/watch?v=S5kOK3bxfro', '2019-03-01 21:25:17', '2019-03-01 22:03:20'),
(2, 'Leg Workouts', 'http://www.workoutbox.net/wp-content/uploads/2018/06/5-legs-workout-at-gym--1024x700.png', 'https://www.youtube.com/watch?v=PIbwfB8jdrQ', '2019-03-01 21:25:17', '2019-03-01 22:03:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Clubs`
--
ALTER TABLE `Clubs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Equipment`
--
ALTER TABLE `Equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clubId` (`clubId`);

--
-- Indexes for table `Reservations`
--
ALTER TABLE `Reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `clubId` (`clubId`);

--
-- Indexes for table `Schedules`
--
ALTER TABLE `Schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainerId` (`trainerId`);

--
-- Indexes for table `SequelizeMeta`
--
ALTER TABLE `SequelizeMeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `Services`
--
ALTER TABLE `Services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clubId` (`clubId`);

--
-- Indexes for table `Trainers`
--
ALTER TABLE `Trainers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clubId` (`clubId`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Workouts`
--
ALTER TABLE `Workouts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Clubs`
--
ALTER TABLE `Clubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Equipment`
--
ALTER TABLE `Equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Reservations`
--
ALTER TABLE `Reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Schedules`
--
ALTER TABLE `Schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Services`
--
ALTER TABLE `Services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `Trainers`
--
ALTER TABLE `Trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Workouts`
--
ALTER TABLE `Workouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Equipment`
--
ALTER TABLE `Equipment`
  ADD CONSTRAINT `Equipment_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `Clubs` (`id`);

--
-- Constraints for table `Reservations`
--
ALTER TABLE `Reservations`
  ADD CONSTRAINT `Reservations_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `Users` (`id`),
  ADD CONSTRAINT `Reservations_ibfk_2` FOREIGN KEY (`clubId`) REFERENCES `Clubs` (`id`);

--
-- Constraints for table `Schedules`
--
ALTER TABLE `Schedules`
  ADD CONSTRAINT `Schedules_ibfk_1` FOREIGN KEY (`trainerId`) REFERENCES `Trainers` (`id`);

--
-- Constraints for table `Services`
--
ALTER TABLE `Services`
  ADD CONSTRAINT `Services_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `Clubs` (`id`);

--
-- Constraints for table `Trainers`
--
ALTER TABLE `Trainers`
  ADD CONSTRAINT `Trainers_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `Clubs` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
